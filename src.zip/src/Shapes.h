#pragma once

#include "ofMain.h"

class Shape {
    public:

    Shape() {}
    virtual void draw() {
        ofPushMatrix();
        ofMultMatrix(getTransform());
        ofDrawBox(defaultSize);
        ofPopMatrix();
    }
    virtual bool inside(glm::vec3 p) { return false; }
    glm::vec3 position = glm::vec3(300,300,0);
    float rotation = 0.0; // degrees
    glm::vec3 scale = glm::vec3(1.0, 1.0, 1.0);
    float defaultSize = 20.0;

    glm::mat4 getTransform() {
        glm::mat4 T = glm::translate(glm::mat4(1.0), position);
        glm::mat4 R = glm::rotate(glm::mat4(1.0), glm::radians(rotation), glm::vec3(0,0,-1));
        glm::mat4 S = glm::scale(glm::mat4(1.0), scale);
        return (T * R * S);
    }

};

class TriangleShape: public Shape {
    public:
    TriangleShape() : headingVisible(true), triangleVisible(true) {}

    void toggleHeading(bool visible) {
        headingVisible = visible;
    }

    void toggleTriangle(bool visible) {
        triangleVisible = visible;
    }

    void setScale(float s) {
        scale = s;
    }

    void draw() {
        ofPushMatrix();   // store current state of transform matrix
        ofMultMatrix(getTransform()); // calculate new matrix

        ofScale(scale, scale);

        if(triangleVisible) {
            ofSetColor(ofColor(70, 130, 180, 255)); // opaque white
        }
        else {
            ofSetColor(ofColor(70, 130, 180, 0));   // fully transparent
        }
        ofDrawTriangle(glm::vec3(-300, -300, 0), glm::vec3(0, 300, 0), glm::vec3(300, -300, 0));
        
        if (headingVisible) {
            ofSetColor(ofColor(255, 255, 255, 255)); // opaque white
        }
        else {
            ofSetColor(ofColor(255, 255, 255, 0));   // fully transparent
        }
        ofDrawLine(glm::vec3(0, 0, 0), glm::vec3(0, 600, 0));
        ofPopMatrix();
    }
    bool inside(glm::vec3 p) {
		glm::vec3 p1 = glm::inverse(getTransform()) * glm::vec4(p, 1);
		return (p1.x > -300 && p1.x < 300 && p1.y > -300 && p1.y < 300 && (p1.y < (-p1.x + 300)) && (p1.y < (p1.x + 300)));
    }

private:
    bool headingVisible;
    bool triangleVisible;
    float scale;

};

class CircleShape: public Shape {
    public:

    CircleShape() {}
    void draw() {
        ofPushMatrix();   // store current state of transform matrix
        ofMultMatrix(getTransform()); // calculate new matrix
        ofSetCircleResolution(500);
        ofSetColor(ofColor::orangeRed);
        ofDrawCircle(glm::vec3(0,0,0), 15);
        ofSetColor(ofColor::white);
        ofDrawLine(glm::vec3(0,0,0), glm::vec3(15,0,0));
        ofPopMatrix();
    }
    bool inside(glm::vec3 p) {
        glm::vec3 p1 = glm::inverse(getTransform()) * glm::vec4(p, 1);
        return ( glm::distance(p1, glm::vec3(0,0,0)) < radius);
    }
    float radius = 20.0;
};

class ImageShape : public Shape {
public:
    ImageShape() : imageVisible(true) {};
    ImageShape(ofImage image) : image(image), imageVisible(true) {}
    void setImage(ofImage image) { this->image = image; }

    void setSize(float s) {
        size = s;
    }

    void toggleImage(bool visible) {
        imageVisible = visible;
    }

    void draw() override {
        ofPushMatrix();   // store current state of transform matrix
        ofMultMatrix(getTransform()); // calculate new matrix
        
        ofScale(size, size);

        if (imageVisible) {
            ofSetColor(255, 255, 255, 255);  // Fully opaque
        }
        else {
            ofSetColor(255, 255, 255, 0);   // Semi-transparent (adjust alpha as needed)
        }
        image.draw(-image.getWidth() / 2.0f, -image.getHeight() / 2.0f, 0);
        ofPopMatrix();
    }
    
    bool inside(glm::vec3 p) {
        glm::vec3 p1 = glm::inverse(getTransform()) * glm::vec4(p, 1);
        return (p1.x > -442 && p1.x < 442 && p1.y > -542 && p1.y < 542 && (p1.y < (-p1.x + 442)) && (p1.y < (p1.x + 442)));
    }

private:
    ofImage image;
    bool imageVisible;
    float size;
};