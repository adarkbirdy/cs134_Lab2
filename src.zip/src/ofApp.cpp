#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

	ofSetVerticalSync(true);

	// create an image for sprites being spawned by emitter
	//
	if (defaultImage.load("space-invaders-ship-scaled.png")) {
		imageLoaded = true;
	}
	else {
		cout << "Can't open image file" << endl;
		ofExit();
	}

	ofSetBackgroundColor(ofColor::black);

	gui.setup("Controls");
	gui.add(headingToggle.setup("Toggle Heading", true));
	gui.add(triangleToggle.setup("Toggle Triangle", true));
	gui.add(imageToggle.setup("Toggle Image", true));
	gui.add(triangleScale.setup("Scale of Triangle", 1.0, 0.1, 3.0));
	gui.add(imageScale.setup("Scale of Image", 1.0, 0.1, 3.0));

	// create small separation between heading/triangle/image options from emitter options
	gui.add(dummySpace.setup("-------------------", 0.0, 0.0, 0.0));

	gui.add(rate.setup("rate", 1, 1, 10));
	gui.add(life.setup("life", 5, .1, 10));
	gui.add(velocity.setup("velocity", ofVec3f(0, -200, 0), ofVec3f(-1000, -1000, -1000), ofVec3f(1000, 1000, 1000)));
	gui.add(scale.setup("Scale", .1, .05, 1.0));
	gui.add(rotationSpeed.setup("Rotation Speed (deg/Frame)", 0, 0, 10));

	bHide = false;

	ofImage img;
	img.load("prettyDecentBall.png");
	image.setImage(img);
	image.position = glm::vec3(400, 300, 0);
	image.rotation = 0.0f;
	image.scale = glm::vec3(1.0f, 1.0f, 1.0f);

	// create an emitter
	emitter = new Emitter();
	emitter->drawable = true; 
	emitter->setChildImage(defaultImage);
	emitter->start();

	// our static emitters
	emitter2 = new Emitter();
	emitter2->drawable = true;
	emitter2->setChildImage(defaultImage);
	emitter2->start();

	emitter3 = new Emitter();
	emitter3->drawable = true;
	emitter3->setChildImage(defaultImage);
	emitter3->start();
	
}

//--------------------------------------------------------------
void ofApp::update() {

	image.position = triangle.position; // keep image position synced with triangle position
	emitter->position = triangle.position + glm::vec3(0, -25, 0); // keep emitter position slightly offset inside triangle anchor point
	
	triangle.toggleHeading(headingToggle);
	triangle.toggleTriangle(triangleToggle);
	triangle.setScale(triangleScale);
	image.toggleImage(imageToggle);
	image.setSize(imageScale);

	emitter->setRate(rate);
	emitter->setLifespan(life * 1000);    // convert to milliseconds 
	// emitter velocity/direction/heading synced to triangle's heading/rotation
	emitter->setVelocity(glm::vec3(sin(glm::radians(triangle.rotation)), cos(glm::radians(triangle.rotation)), 0) * 300);
	emitter->update();

	for (int i = 0; i < emitter->sys->sprites.size(); i++) {

		// Get values from sliders and update sprites dynamically
		float sc = triangleScale; // looks weird but just ties size of projectile to triangle shape
		float rs = rotationSpeed;
		emitter->sys->sprites[i].scale = glm::vec3(sc, sc, sc);
		emitter->sys->sprites[i].rotationSpeed = rs;
	}

	// static emitters firing projectiles in fixed directions from fixed positions
	emitter2->position = glm::vec3(200, 1000, 0);
	emitter2->setRate(rate);
	emitter2->setLifespan(life * 1000);
	emitter2->setVelocity(glm::vec3(25, -100, 0) * 2);
	emitter2->update();
	for (int i = 0; i < emitter2->sys->sprites.size(); i++) {
		float sc = scale;
		float rs = rotationSpeed;
		emitter2->sys->sprites[i].scale = glm::vec3(sc, sc, sc);
		emitter2->sys->sprites[i].rotationSpeed = rs;
	}

	emitter3->position = glm::vec3(2500, 1000, 0);
	emitter3->setRate(rate);
	emitter3->setLifespan(life * 1000);
	emitter3->setVelocity(glm::vec3(-25, -100, 0) * 2);
	emitter3->update();
	for (int i = 0; i < emitter3->sys->sprites.size(); i++) {

		float sc = scale;
		float rs = rotationSpeed;
		emitter3->sys->sprites[i].scale = glm::vec3(sc, sc, sc);
		emitter3->sys->sprites[i].rotationSpeed = rs;
	}

	// if rotating to target, calculate angle to target and rotate towards it
	if (rotatingToTarget) {
		glm::vec3 toTarget = glm::normalize(target - triangle.position); // glm::normalize to get unit vector

		// triangle heading/direction is the heading vector after transformation
		glm::vec3 heading = glm::vec3(triangle.getTransform() * glm::vec4(0, 1, 0, 0));
		heading = glm::normalize(heading);

		// dot product to find angle between heading and toTarget
		float dot = glm::dot(heading, toTarget);
		dot = glm::clamp(dot, -1.0f, 1.0f);  // glm::clamp to smooth out floating point

		// compute angle (in degrees)
		float angleDiff = glm::degrees(acos(dot));

		// cross product to find direction
		float direction = glm::cross(heading, toTarget).z;

		if (angleDiff < rotateSpeed) {
			// stop rotating if angle is pretty close
			rotatingToTarget = false;
			std::cout << "locked on target!" << std::endl;
		}
		else {
			// keep rotating towards target point
			if (direction > 0) {
				triangle.rotation -= rotateSpeed; // rotate counter-clockwise
				image.rotation -= rotateSpeed;
			}
			else {
				triangle.rotation += rotateSpeed; // rotate clockwise
				image.rotation += rotateSpeed;
			}
		}
	}

}


//--------------------------------------------------------------
void ofApp::draw(){

	triangle.draw();
	image.draw();
	if (rotatingToTarget) {
		ofSetColor(ofColor::red);
		ofDrawCircle(target, 15);
		ofSetColor(ofColor::white);
	}

	emitter->draw();
	emitter2->draw();
	emitter3->draw();
	
	if (!bHide) {
		gui.draw();
	}
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
	// update position of triangle towards mouse position when left mouse button is held down inside triangle but preserve relative position
	if (button == OF_MOUSE_BUTTON_LEFT) {
		if (triangle.inside(glm::vec3(x, y, 0))) {
			triangle.position = glm::vec3(x, y, 0);
		}
		if (image.inside(glm::vec3(x, y, 0))) {
			image.position = glm::vec3(x, y, 0);
		}
	}
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
	// left click inside triangle, button is left mouse button
	if (button == OF_MOUSE_BUTTON_LEFT) {
		if (triangle.inside(glm::vec3(x, y, 0))) {
			std::cout << "left click inside triangle" << std::endl;
		}
		if (image.inside(glm::vec3(x, y, 0))) {
			std::cout << "left click inside ball" << std::endl;
		}
	}

	lockOn(x, y, button);
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
	if (triangle.inside(glm::vec3(x, y, 0))) {
		std::cout << "inside triangle" << std::endl;
	}
	if (image.inside(glm::vec3(x, y, 0))) {
		std::cout << "inside ball" << std::endl;
	}
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
	// when mouse is outside triangle, log it
	if (!triangle.inside(glm::vec3(x, y, 0))) {
		std:cout << "outside triangle" << std::endl;
	}
}

void ofApp::keyPressed(int key) {

	if (key == OF_KEY_LEFT) {
		triangle.rotation += 5.0;
		image.rotation += 5.0;
	}
	if (key == OF_KEY_RIGHT) {
		triangle.rotation -= 5.0;
		image.rotation -= 5.0;
	}

	// supports object forwards/backwards movement with up/down arrow keys with respect to its current heading, use getTransform() to get current transformation matrix
	if (key == OF_KEY_UP) {
		glm::vec4 dir = glm::vec4(0, 10, 0, 0); // direction vector
		glm::vec4 triDir = triangle.getTransform() * dir;
		triangle.position += glm::vec3(triDir); // update position in direction of heading
		dir = image.getTransform() * dir;
		image.position += glm::vec3(dir);
	}
	if (key == OF_KEY_DOWN) { // same as above but backwards
		glm::vec4 dir = glm::vec4(0, -10, 0, 0);
		glm::vec4 triDir = triangle.getTransform() * dir;
		triangle.position += glm::vec3(triDir);
		dir = image.getTransform() * dir;
		image.position += glm::vec3(dir);
	}

	switch (key) {
	case 'C':
	case 'c':
		break;
	case 'F':
	case 'f':
		ofToggleFullscreen();
		break;
	case 'H':
	case 'h':
		bHide = !bHide;
		break;
	case 'r':
		break;
	case 's':
		break;
	case 'u':
		break;
	case OF_KEY_ALT:
		break;
	case OF_KEY_CONTROL:
		break;
	case OF_KEY_SHIFT:
		break;
	case OF_KEY_DEL:
		break;
	}
}


//--------------------------------------------------------------
void ofApp::keyReleased(int key) {
	switch (key) {
	case OF_KEY_LEFT:
	case OF_KEY_RIGHT:
	case OF_KEY_UP:
	case OF_KEY_DOWN:
		break;
	case OF_KEY_ALT:
		break;
	case OF_KEY_CONTROL:
		break;
	case OF_KEY_SHIFT:
		break;
	}
}

void ofApp::lockOn(int x, int y, int button) {
	// need to use ofGetKeyPressed to check if control key is held down
	if (ofGetKeyPressed(OF_KEY_LEFT_CONTROL) && button == OF_MOUSE_BUTTON_LEFT) {
		//draw small circle at mouse position
		circle.position = glm::vec3(x, y, 0);
		circle.draw();

		target = glm::vec3(x, y, 0);
		rotatingToTarget = true;
		std::cout << "locking on target at " << x << ", " << y << std::endl;
	}
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

