#pragma once

#include "ofMain.h"
#include "ofxGui.h"
#include "Emitter.h"
#include "Shapes.h"



class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void lockOn(int x, int y, int button);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		


		Emitter  *emitter = NULL;
		Emitter  *emitter2 = NULL;
		Emitter  *emitter3 = NULL;

		ofImage defaultImage;
		ofVec3f mouse_last;
		bool imageLoaded;

		// Some basic UI
		//
		bool bHide;
		ofxFloatSlider rate;
		ofxFloatSlider life;
		ofxVec3Slider velocity;
		ofxLabel screenSize;
		ofxFloatSlider scale;
		ofxFloatSlider rotationSpeed = 3.0;


		ofxPanel gui;
		ofxToggle headingToggle;
		ofxToggle triangleToggle;
		ofxToggle imageToggle;
		ofxFloatSlider triangleScale;
		ofxFloatSlider imageScale;
		ofxFloatSlider dummySpace;

		glm::vec3 target;
		bool rotatingToTarget = false;
		float rotateSpeed = 2.0; // degrees per frame


	private:
		CircleShape circle;
		TriangleShape triangle;
		ImageShape image;
};
